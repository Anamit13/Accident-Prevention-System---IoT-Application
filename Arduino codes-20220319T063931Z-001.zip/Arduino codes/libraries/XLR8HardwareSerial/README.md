# XLR8HardwareSerial

Provides identical functionality to the Arduino UART, but using OpenXLR8 a hardware UART interface can be put on arbitrary pins and accessed via this library.

In the default build the extra UART will put TX on D11 and RX on D10.

